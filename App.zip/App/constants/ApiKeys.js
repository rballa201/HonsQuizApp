///////////////////////////////////////////
/// Name: Ryan Ballantine
/// Matric Number: S1829049
/// Title: Honours Code
////////////////////////////////////////////
export default {
    FirebaseConfig: {
        apiKey: "AIzaSyAhSwv5CWyCjoYSzCE9_VGVpqu0HddThh8",
        authDomain: "native-quiz-app.firebaseapp.com",
        databaseURL: "https://native-quiz-app.firebaseio.com",
        projectId: "native-quiz-app",
        storageBucket: "native-quiz-app.appspot.com",
        messagingSenderId: "12110411814",
        appId: "1:12110411814:web:f81b7fda9e0dde4a040ee7",
        measurementId: "G-W9TTRTNWN0"
    }
}